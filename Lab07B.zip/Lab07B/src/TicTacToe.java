import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TicTacToeGame extends JFrame {
    private TTTBoard board;
    private TTTTileButton[] buttons;
    private TTTPlayer player1;
    private TTTPlayer player2;
    private TTTPlayer currentPlayer;

    public TicTacToeGame() {

        board = new TTTBoard();
        player1 = new TTTPlayer("Player 1", "X");
        player2 = new TTTPlayer("Player 2", "O");
        currentPlayer = player1;
        buttons = new TTTTileButton[9];

        setTitle("Tic Tac Toe");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 3));


        for (int i = 0; i < 9; i++) {
            buttons[i] = new TTTTileButton(i);
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 48));
            buttons[i].addActionListener(new TileButtonListener());
            add(buttons[i]);
        }

        pack();
        setLocationRelativeTo(null);
    }

    private class TileButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            TTTTileButton button = (TTTTileButton) e.getSource();
            int position = button.getPosition();

            if (board.isLegalMove(position)) {
                // Make the move and update the button
                board.makeMove(currentPlayer, position);
                button.setText(currentPlayer.getSymbol());

                // Check for a win or a draw
                if (board.checkWin(currentPlayer)) {
                    JOptionPane.showMessageDialog(TicTacToeGame.this, currentPlayer.getName() + " wins!");
                    resetGame();
                } else if (board.isFull()) {
                    JOptionPane.showMessageDialog(TicTacToeGame.this, "It's a draw!");
                    resetGame();
                } else {
                    // Switch to the next player
                    currentPlayer = (currentPlayer == player1) ? player2 : player1;
                }
            }
        }
    }

    private void resetGame() {
        // Clear the board and buttons for a new game
        board.clearBoard();
        for (TTTTileButton button : buttons) {
            button.setText("");
        }
        currentPlayer = player1;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TicTacToeGame game = new TicTacToeGame();
            game.setVisible(true);
        });
    }
}
